## Mutation Testing Results

- **Status:** ⚠️  Some tests timed out (acceptable)
- **Total Mutants:** 331
- **Caught:** 252
- **Missed:** 56
- **Timeout:** 1
- **Unviable:** 22
- **Mutation Score:** 76.13%

Full report available in artifacts.
